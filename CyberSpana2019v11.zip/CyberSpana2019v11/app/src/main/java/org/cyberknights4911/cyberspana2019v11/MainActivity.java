package org.cyberknights4911.cyberspana2019v11;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    View constraintLayout;

    EditText matchNumberEditText, scoutIDEditText, teamNumberEditText;

    ToggleButton toggleAllianceColor,
            toggleRobotProblem, toggleFouls;

    Button btnKindleID, btnSwitchSandstormStatus, btnSandStormDeploy,
            plusBtnLv3HatchPanel, minusBtnLv3HatchPanel,
            plusBtnLv2HatchPanel, minusBtnLv2HatchPanel,
            plusBtnLv1HatchPanel, minusBtnLv1HatchPanel,
            plusBtnLv3Cargo, minusBtnLv3Cargo,
            plusBtnLv2Cargo, minusBtnLv2Cargo,
            plusBtnLv1Cargo, minusBtnLv1Cargo,
            plusBtnCargoShipCargo, minusBtnCargoShipCargo,
            plusBtnCargoShipHatchPanel, minusBtnCargoShipHatchPanel,
            btnClimb, btnDefense, btnCards, btnReset, btnSave, btnChangeMatchData;

    TextView textViewHatchPanelLv3, textViewHatchPanelLv2, textViewHatchPanelLv1, textViewCargoShipHatchPanel,
            textViewCargoLv3, textViewCargoLv2, textViewCargoLv1, textViewCargoShipCargo;

    Switch resetProtection;

    public final String eventName = "PNW";
    public String alliColorString;

    int intMatchNumber, intScoutID, intAllianceColor, intKindleID,

    intTeamNumber,

    intLv3HatchPanel, intLv2HatchPanel, intLv1HatchPanel,
            intLv3Cargo, intLv2Cargo, intLv1Cargo,
            intCargoshipHatchPanel, intCargoshipCargo,

    intSandStormDeploy,

    intSandStormLv3HatchPanel, intSandStormLv2HatchPanel, intSandStormLv1HatchPanel,
            intSandStormLv3Cargo, intSandStormLv2Cargo, intSandStormLv1Cargo,
            intSandStormCargoshipHatchPanel, intSandStormCargoshipCargo,

    intClimb, intDefense, intRobotProblems, intFouls, intCards;

    boolean matchInformationEditable = true;
    boolean isSandstormPeriod = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setTitle("Cyber Spana 2019");         // sets the text on the action bar to the name of the app
        setContentView(R.layout.activity_main);

        constraintLayout = findViewById(R.id.constraintLayout);

        // Initialize all edit texts
        matchNumberEditText = findViewById(R.id.matchNumEditText);
        teamNumberEditText = findViewById(R.id.teamNumEditText);
        scoutIDEditText = findViewById(R.id.scoutIDEditText);

        //initialize all toggle buttons
        toggleAllianceColor = findViewById(R.id.toggleAlliColor);
        toggleRobotProblem = findViewById(R.id.toggleRobotProblem);
        toggleFouls = findViewById(R.id.toggleFouls);

        //initialize all buttons
        btnKindleID = findViewById(R.id.btnKindleID);
        btnSwitchSandstormStatus = findViewById(R.id.btnSwitchSandStormStatus);
        btnSandStormDeploy = findViewById(R.id.btnSandStormDeploy);

        plusBtnLv3HatchPanel = findViewById(R.id.plusBtnLv3HatchPanel);
        plusBtnLv2HatchPanel = findViewById(R.id.plusBtnLv2HatchPanel);
        plusBtnLv1HatchPanel = findViewById(R.id.plusBtnLv1HatchPanel);

        minusBtnLv3HatchPanel = findViewById(R.id.minusBtnLv3HatchPanel);
        minusBtnLv2HatchPanel = findViewById(R.id.minusBtnLv2HatchPanel);
        minusBtnLv1HatchPanel = findViewById(R.id.minusBtnLv1HatchPanel);

        plusBtnLv3Cargo = findViewById(R.id.plusBtnLv3Cargo);
        plusBtnLv2Cargo = findViewById(R.id.plusBtnLv2Cargo);
        plusBtnLv1Cargo = findViewById(R.id.plusBtnLv1Cargo);

        minusBtnLv3Cargo = findViewById(R.id.minusBtnLv3Cargo);
        minusBtnLv2Cargo = findViewById(R.id.minusBtnLv2Cargo);
        minusBtnLv1Cargo = findViewById(R.id.minusBtnLv1Cargo);

        plusBtnCargoShipHatchPanel = findViewById(R.id.plusBtnCargoShipHatchPanel);
        minusBtnCargoShipHatchPanel = findViewById(R.id.minusBtnCargoShipHatchPanel);

        plusBtnCargoShipCargo = findViewById(R.id.plusBtnCargoShipCargo);
        minusBtnCargoShipCargo = findViewById(R.id.minusBtnCargoShipCargo);

        btnClimb = findViewById(R.id.btnClimb);
        btnDefense = findViewById(R.id.btnDefense);
        btnCards = findViewById(R.id.btnCards);
        btnReset = findViewById(R.id.btnReset);
        btnSave = findViewById(R.id.btnSave);
        btnChangeMatchData = findViewById(R.id.btnChangeMatchData);

        //initialize all text views
        textViewHatchPanelLv3 = findViewById(R.id.textViewHatchPanelLv3);
        textViewHatchPanelLv2 = findViewById(R.id.textViewHatchPanelLv2);
        textViewHatchPanelLv1 = findViewById(R.id.textViewHatchPanelLv1);

        textViewCargoLv3 = findViewById(R.id.textViewCargoLv3);
        textViewCargoLv2 = findViewById(R.id.textViewCargoLv2);
        textViewCargoLv1 = findViewById(R.id.textViewCargoLv1);

        textViewCargoShipHatchPanel = findViewById(R.id.textViewCargoShipHatchPanel);
        textViewCargoShipCargo = findViewById(R.id.textViewCargoShipCargo);

        //initialize all switches
        resetProtection = findViewById(R.id.switchResetProtection);
        resetProtection.setChecked(true);

        //initialize all ints that needs to be initialized

        intKindleID = 1;

        zeroAllData();

        btnSandStormDeploy.setEnabled(false);
    }

    public void clickKindleID(View v){

        intKindleID++;

        if( intKindleID > 7 ){
            intKindleID = 1;
        }

        btnKindleID.setText("Kindle:" + intKindleID);

    }

    public void clickSwitchSandStormStatus(View v){

        isSandstormPeriod = !isSandstormPeriod;

        if(isSandstormPeriod) {

            constraintLayout.setBackgroundColor(Color.argb(255,255,175,71));
            btnSwitchSandstormStatus.setText("In Sandstorm Mode");

        } else {

            constraintLayout.setBackgroundColor(Color.argb(255,255,255,255));
            btnSwitchSandstormStatus.setText("Switch To Sandstorm Mode");

        }

        btnSandStormDeploy.setEnabled(isSandstormPeriod);
        btnClimb.setEnabled(!isSandstormPeriod);
        btnDefense.setEnabled(!isSandstormPeriod);
        btnReset.setEnabled(!isSandstormPeriod);
        btnSave.setEnabled(!isSandstormPeriod);
        btnChangeMatchData.setEnabled(!isSandstormPeriod);
        resetProtection.setEnabled(!isSandstormPeriod);

        setAllTextFieldToStatus();

    }

    public void clickPlusBtnLv3HatchPanel (View v) {

        if (isSandstormPeriod){

            intSandStormLv3HatchPanel++;

            if (intSandStormLv3HatchPanel > 4) {

                intSandStormLv3HatchPanel = 4;

            }

        } else {

            intLv3HatchPanel++;

            if (intLv3HatchPanel > 4) {

                intLv3HatchPanel = 4;

            }


        }

        setAllTextFieldToStatus();

    }

    public void clickPlusBtnLv2HatchPanel (View v) {

        if (isSandstormPeriod){

            intSandStormLv2HatchPanel++;

            if (intSandStormLv2HatchPanel > 4) {

                intSandStormLv2HatchPanel = 4;

            }

        } else {

            intLv2HatchPanel++;

            if (intLv2HatchPanel > 4) {

                intLv2HatchPanel = 4;

            }

        }


        setAllTextFieldToStatus();

    }

    public void clickPlusBtnLv1HatchPanel (View v) {

        if (isSandstormPeriod){

            intSandStormLv1HatchPanel++;

            if (intSandStormLv1HatchPanel > 4) {

                intSandStormLv1HatchPanel = 4;

            }

        } else {

            intLv1HatchPanel++;

            if (intLv1HatchPanel > 4) {

                intLv1HatchPanel = 4;

            }

        }


        setAllTextFieldToStatus();

    }

    public void clickPlusBtnLv3Cargo (View v) {

        if (isSandstormPeriod){

            intSandStormLv3Cargo++;

            if (intSandStormLv3Cargo > 4) {

                intSandStormLv3Cargo = 4;

            }

        } else {

            intLv3Cargo++;

            if (intLv3Cargo > 4) {

                intLv3Cargo = 4;

            }


        }


        setAllTextFieldToStatus();

    }

    public void clickPlusBtnLv2Cargo (View v) {

        if (isSandstormPeriod){

            intSandStormLv2Cargo++;

            if (intSandStormLv2Cargo > 4) {

                intSandStormLv2Cargo = 4;

            }


        } else {

            intLv2Cargo++;

            if (intLv2Cargo > 4) {

                intLv2Cargo = 4;

            }


        }


        setAllTextFieldToStatus();

    }

    public void clickPlusBtnLv1Cargo (View v) {

        if (isSandstormPeriod){

            intSandStormLv1Cargo++;

            if (intSandStormLv1Cargo > 4) {

                intSandStormLv1Cargo = 4;

            }

        } else {

            intLv1Cargo++;

            if (intLv1Cargo > 4) {

                intLv1Cargo = 4;

            }


        }


        setAllTextFieldToStatus();

    }

    public void clickMinusBtnLv3HatchPanel (View v) {

        if (isSandstormPeriod){

            intSandStormLv3HatchPanel--;

            if (intSandStormLv3HatchPanel < 0) {

                intSandStormLv3HatchPanel = 0;

            }

        } else {

            intLv3HatchPanel--;

            if (intLv3HatchPanel < 0) {

                intLv3HatchPanel = 0;

            }

        }

        setAllTextFieldToStatus();

    }

    public void clickMinusBtnLv2HatchPanel (View v) {

        if (isSandstormPeriod){

            intSandStormLv2HatchPanel--;

            if (intSandStormLv2HatchPanel < 0) {

                intSandStormLv2HatchPanel= 0;

            }

        } else {

            intLv2HatchPanel--;

            if (intLv2HatchPanel < 0) {

                intLv2HatchPanel= 0;

            }

        }

        setAllTextFieldToStatus();

    }

    public void clickMinusBtnLv1HatchPanel (View v) {

        if (isSandstormPeriod){

            intSandStormLv1HatchPanel--;

            if (intSandStormLv1HatchPanel < 0) {

                intSandStormLv1HatchPanel= 0;

            }

        } else {

            intLv1HatchPanel--;

            if (intLv1HatchPanel < 0) {

                intLv1HatchPanel= 0;

            }

        }

        setAllTextFieldToStatus();

    }

    public void clickMinusBtnLv3Cargo (View v) {

        if (isSandstormPeriod){

            intSandStormLv3Cargo--;

            if (intSandStormLv3Cargo < 0) {

                intSandStormLv3Cargo= 0;

            }

        } else {

            intLv3Cargo--;

            if (intLv3Cargo < 0) {

                intLv3Cargo= 0;

            }

        }

        setAllTextFieldToStatus();

    }

    public void clickMinusBtnLv2Cargo (View v) {

        if (isSandstormPeriod){

            intSandStormLv2Cargo--;

            if (intSandStormLv2Cargo < 0) {

                intSandStormLv2Cargo= 0;

            }

        } else {

            intLv2Cargo--;

            if (intLv2Cargo < 0) {

                intLv2Cargo= 0;

            }

        }

        setAllTextFieldToStatus();

    }

    public void clickMinusBtnLv1Cargo (View v) {

        if (isSandstormPeriod){

            intSandStormLv1Cargo--;

            if (intSandStormLv1Cargo < 0) {

                intSandStormLv1Cargo= 0;

            }

        } else {

            intLv1Cargo--;

            if (intLv1Cargo < 0) {

                intLv1Cargo= 0;

            }

        }

        setAllTextFieldToStatus();

    }

    public void clickMinusCargoshipCargo (View v) {

        if (isSandstormPeriod){

           intSandStormCargoshipCargo--;

            if (intSandStormCargoshipCargo < 0) {

                intSandStormCargoshipCargo = 0;

            }

        } else {

            intCargoshipCargo--;

            if (intCargoshipCargo < 0) {

                intCargoshipCargo = 0;

            }

        }

        setAllTextFieldToStatus();

    }

    public void clickPlusCargoshipCargo (View v) {

        if (isSandstormPeriod){

            intSandStormCargoshipCargo++;

            if (intSandStormCargoshipCargo > 8) {

                intSandStormCargoshipCargo = 8;

            }

        } else {

            intCargoshipCargo++;

            if (intCargoshipCargo > 8) {

                intCargoshipCargo = 8;

            }

        }


        setAllTextFieldToStatus();

    }

    public void clickMinusCargoshipHatchPanel (View v) {

        if (isSandstormPeriod){

            intSandStormCargoshipHatchPanel--;

            if (intSandStormCargoshipHatchPanel < 0) {

                intSandStormCargoshipHatchPanel = 0;

            }

        } else {

            intCargoshipHatchPanel--;

            if (intCargoshipHatchPanel < 0) {

                intCargoshipHatchPanel = 0;

            }

        }

        setAllTextFieldToStatus();

    }

    public void clickPlusCargoshipHatchPanel (View v) {

        if (isSandstormPeriod){

            intSandStormCargoshipHatchPanel++;

            if (intSandStormCargoshipHatchPanel > 8) {

                intSandStormCargoshipHatchPanel = 8;

            }


        } else {

            intCargoshipHatchPanel++;

            if (intCargoshipHatchPanel > 8) {

                intCargoshipHatchPanel= 8;

            }


        }


        setAllTextFieldToStatus();

    }



    public void clickSandStormDeploy(View v){

        intSandStormDeploy++;

        if (intSandStormDeploy > 2){
            intSandStormDeploy = 0;
        }

        switch (intSandStormDeploy){

            case 0:
                btnSandStormDeploy.setText("No Deploy");
                break;

            case 1:
                btnSandStormDeploy.setText("Lv.1 Deploy");
                break;

            case 2:
                btnSandStormDeploy.setText("Lv.2 Deploy");
        }

    }

    public void clickCard(View V){

        intCards++;

        if (intCards > 2){
            intCards = 0;
        }

        switch (intCards){
            case 0:
                btnCards.setText("No Cards");
                break;

            case 1:
                btnCards.setText("Yellow Card");
                break;

            case 2:
                btnCards.setText("RED CARD");
                break;
        }

    }

    public int convertBooleanToInt(boolean bool){

        if (bool){

            return 1;

        } else {

            return 0;

        }

    }


    public void zeroAllData(){



        intTeamNumber = 0;

        intLv3HatchPanel = 0;
        intLv2HatchPanel = 0;
        intLv1HatchPanel = 0;

        intLv3Cargo = 0;
        intLv2Cargo = 0;
        intLv1Cargo = 0;

        intCargoshipHatchPanel = 0;
        intCargoshipCargo = 0;

        intSandStormDeploy = 0;

        intSandStormLv3HatchPanel = 0;
        intSandStormLv2HatchPanel = 0;
        intSandStormLv1HatchPanel = 0;

        intSandStormLv3Cargo = 0;
        intSandStormLv2Cargo = 0;
        intSandStormLv1Cargo = 0;

        intSandStormCargoshipHatchPanel = 0;
        intSandStormCargoshipCargo = 0;

        intClimb = 0;
        intDefense = 0;
        intCards = 0;
        intRobotProblems = 0;
        intFouls = 0;

    }

    public void setAllTextFieldToStatus(){
        if(isSandstormPeriod){

            textViewHatchPanelLv3.setText(Integer.toString(intSandStormLv3HatchPanel));
            textViewHatchPanelLv2.setText(Integer.toString(intSandStormLv2HatchPanel));
            textViewHatchPanelLv1.setText(Integer.toString(intSandStormLv1HatchPanel));
            textViewCargoLv3.setText(Integer.toString(intSandStormLv3Cargo));
            textViewCargoLv2.setText(Integer.toString(intSandStormLv2Cargo));
            textViewCargoLv1.setText(Integer.toString(intSandStormLv1Cargo));

            textViewCargoShipHatchPanel.setText("Hatch Panel = " + Integer.toString(intSandStormCargoshipHatchPanel));
            textViewCargoShipCargo.setText("Cargo = " + Integer.toString(intSandStormCargoshipCargo));

        } else {

            textViewHatchPanelLv3.setText(Integer.toString(intLv3HatchPanel));
            textViewHatchPanelLv2.setText(Integer.toString(intLv2HatchPanel));
            textViewHatchPanelLv1.setText(Integer.toString(intLv1HatchPanel));
            textViewCargoLv3.setText(Integer.toString(intLv3Cargo));
            textViewCargoLv2.setText(Integer.toString(intLv2Cargo));
            textViewCargoLv1.setText(Integer.toString(intLv1Cargo));

            textViewCargoShipHatchPanel.setText("Hatch Panel = " + Integer.toString(intCargoshipHatchPanel));
            textViewCargoShipCargo.setText("Cargo = "  + Integer.toString(intCargoshipCargo));


        }

    }

    public void clickClimb(View v){

        intClimb++;

        if( intClimb > 5 ){
            intClimb = 0;
        }

        switch ( intClimb ){

            case 0:
                btnClimb.setText("No Climb");
                break;

            case 1:
                btnClimb.setText("Lv.1 Climb");
                break;

            case 2:
                btnClimb.setText("Lv.2 Climb");
                break;

            case 3:
                btnClimb.setText("Lv.3 Climb");
                break;

            case 4:
                btnClimb.setText("Lv.3 Climb *2");
                break;

            case 5:
                btnClimb.setText("Lv.3 Climb *3");
                break;

        }

    }

    public void clickDefense(View v){

        intDefense++;

        if( intDefense > 2 ){
            intDefense = 0;
        }

        switch ( intDefense ){

            case 0:
                btnDefense.setText("No Defense played");
                break;

            case 1:
                btnDefense.setText("Played Defense");
                break;

            case 2:
                btnDefense.setText("Was Defended");
                break;

        }

    }

    public void clickReset(View v){

        if (resetProtection.isChecked()){

            Toast.makeText(MainActivity.this, "Disable Reset Protection First Before Resetting", Toast.LENGTH_SHORT).show();

        } else {

            matchInformationEditable = false;

            intMatchNumber++;
            matchNumberEditText.setText(Integer.toString(intMatchNumber));

            setMatchInfoEditability(false);
            zeroAllData();
            setAllTextFieldToStatus();

            teamNumberEditText.setText("");
            btnSandStormDeploy.setText("No Deploy");
            btnClimb.setText("No Climb");
            btnDefense.setText("No Defense Played");
            toggleRobotProblem.setChecked(false);
            toggleFouls.setChecked(false);
            btnCards.setText("No Card");
            resetProtection.setChecked(true);

        }

    }

    public void clickSave(View v) throws IOException{

        if( isEmpty(matchNumberEditText) || isEmpty(teamNumberEditText) || isEmpty(scoutIDEditText) ){

            // if either of the three is empty, take no action but display the error message to the user to prevent the int from being given a invalid value
            // and therefore causing the app to crash
            Toast.makeText(MainActivity.this, "Error: Match Number, Team Number, and Scout ID cannot be empty", Toast.LENGTH_SHORT).show();

        } else  {

            intMatchNumber = Integer.parseInt(matchNumberEditText.getText().toString());
            intTeamNumber = Integer.parseInt(teamNumberEditText.getText().toString());
            intScoutID = Integer.parseInt(scoutIDEditText.getText().toString());
            intAllianceColor = convertBooleanToInt(toggleAllianceColor.isChecked());
            intRobotProblems = convertBooleanToInt(toggleRobotProblem.isChecked());
            intFouls = convertBooleanToInt(toggleFouls.isChecked());

            writeFile();

        }

    }

    public void setMatchInfoEditability(boolean bool){

        matchNumberEditText.setEnabled(bool);
        toggleAllianceColor.setEnabled(bool);
        btnKindleID.setEnabled(bool);

    }

    public boolean isEmpty(EditText etText) { // a method to check if an edit text is empty

        return etText.getText().toString().trim().length() == 0;

    }

    public void writeFile() throws IOException{

        if (intAllianceColor == 1){
            alliColorString = "Red";
        }
        else{
            alliColorString = "Blue";
        }

        String fileName = "Peak_Performance_Kindle_" + intKindleID + ".csv";


        if(checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)){
            File csvFile = Environment.getExternalStorageDirectory();
            csvFile = new File(csvFile, fileName);

            csvFile.setExecutable(true);
            csvFile.setReadable(true);
            csvFile.setWritable(true);

            BufferedWriter b = new BufferedWriter(new FileWriter(csvFile, true));

            write(b, intMatchNumber);
            write(b, intTeamNumber);
            write(b, intScoutID);
            write(b, intAllianceColor);
            write(b, intKindleID);
            write(b, intSandStormDeploy);
            write(b, intSandStormLv3HatchPanel);
            write(b, intSandStormLv2HatchPanel);
            write(b, intSandStormLv1HatchPanel);
            write(b, intSandStormLv3Cargo);
            write(b, intSandStormLv2Cargo);
            write(b, intSandStormLv1Cargo);
            write(b, intSandStormCargoshipHatchPanel);
            write(b, intSandStormCargoshipCargo);
            write(b, intLv3HatchPanel);
            write(b, intLv2HatchPanel);
            write(b, intLv1HatchPanel);
            write(b, intLv3Cargo);
            write(b, intLv2Cargo);
            write(b, intLv1Cargo);
            write(b, intCargoshipHatchPanel);
            write(b, intCargoshipCargo);
            write(b, intClimb);
            write(b, intDefense);
            write(b, intRobotProblems);
            write(b, intFouls);
            write(b, intCards);
            b.append("\n");
            b.close();

            MediaScannerConnection.scanFile(this, new String[] {csvFile.toString()}, null, null);

            Toast.makeText(this, "File Saved To Internal Storage", Toast.LENGTH_SHORT).show();
        }else{

            Toast.makeText(this, "Cannot Write To Internal Storage", Toast.LENGTH_SHORT).show();

        }

    }

    public boolean checkPermission(String permission){

        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);

    }

    public void clickChangeMatchData(View v){

        matchInformationEditable = !matchInformationEditable;

        setMatchInfoEditability(matchInformationEditable);

        if (matchInformationEditable){

            constraintLayout.setBackgroundColor(Color.argb(255,255,0,0));

        } else {

            constraintLayout.setBackgroundColor(Color.argb(255,255,255,255));

        }

    }

    public void write(BufferedWriter b, int i){
        try {
            b.append(Integer.toString(i) + ",");
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

}